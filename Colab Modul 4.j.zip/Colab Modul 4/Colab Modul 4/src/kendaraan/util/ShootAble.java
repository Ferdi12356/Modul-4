package kendaraan.util;

//inter -> interface
public interface ShootAble {
    void Shoot(String vehicle);
}
