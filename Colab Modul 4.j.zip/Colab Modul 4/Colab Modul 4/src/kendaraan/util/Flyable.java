package kendaraan.util;

public interface Flyable {
    //tipe data private dihapus
    void fly();
}
